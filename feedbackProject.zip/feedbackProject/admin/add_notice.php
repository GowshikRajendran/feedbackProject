<?php 
extract($_POST);
if(isset($add))
{

	if($details=="" || $sub=="" || $user=="")
	{
		if($details != "" || $sub != "" || $user==""){
			$sql=mysqli_query($conn,"select name,email from user where yearofstudy='$yearofstudy' and dept = '$dept' and sec='$sec'");
			$user=mysqli_fetch_array($sql);
			foreach($user as $v)
				{
					mysqli_query($conn,"insert into notice values('','$v','$sub','$details',now())");
				}
		
		$err="<font color='green'>Notice added Successfully</font>";	
		}else{
			$err="<font color='red'>fill all the fileds first</font>";	
		}
	}
	else
	{
		foreach($user as $v)
		{
			mysqli_query($conn,"insert into notice values('','$v','$sub','$details',now())");
		}
		
		$err="<font color='green'>Notice added Successfully</font>";	
	}
}

?>
<script>
function myFunction() {
  var x = document.getElementById("mySelect").value;
  if(x == "Specific Students"){
	$("#mySelect2").css("display","block");
	$("#mySelect1").css("display","none");
  }else{
	$("#mySelect2").css("display","none");
	$("#mySelect1").css("display","block");
	$user="";
  }
}
function userCreation() {
  var x = document.getElementById("mySelect").value;
}

</script>
<h2>Add New Notice</h2>
<form method="post" name="myform">
	
	<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><?php echo @$err;?></div>
	</div>
	
	<div class="row">
		<div class="col-sm-4">Enter Subject</div>
		<div class="col-sm-5">
		<input type="text" name="sub" class="form-control"/></div>
	</div>
	
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
	</div>	
	
	<div class="row" >
		<div class="col-sm-4">Enter Details</div>
		<div class="col-sm-5">
		<textarea name="details" class="form-control"></textarea></div>
	</div>
	
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
	</div>	
	<div class="row" style="margin-left: 1%;">		
		<div class="col-sm-4">Notifications Sending type</div>
		<select name="pro" id="mySelect" onchange="myFunction()" required="" style="margin-bottom: 2%;float: left;">	
			<option>Whole Class Students</option>
			<option>Specific Students</option>
		</select>
	</div>
	<div class="row" id="mySelect1">
		<div class="col-sm-4">Select Class</div>
		<div class="col-sm-5">					
			<select name="yearofstudy">	
				<option>I</option>
				<option>II</option>
				<option>III</option>
				<option>IV</option>
			</select>
		</div>
		<div class="col-sm-5">					
			<select name="dept" style="padding-right: 3%;    margin-top: 3%;    float: right;">		
				<option>CSE</option>
				<option>ECE</option>
				<option>EEE</option>
			</select>
		</div>
		<div class="col-sm-5">					
			<select name="sec" style="padding-right: 3%;    margin-bottom: 3%;    margin-top: 3%;" onchange="userCreation()">		
				<option>A</option>
				<option>B</option>
				<option>C</option>
				<option>D</option> 
			</select>
		</div>
	</div>
	
	<div class="row" id="mySelect2" style="display:none;">
		<div class="col-sm-4">Select Student</div>
		<div class="col-sm-5">
		<select name="user[]" multiple="multiple" class="form-control">
			<?php 
	$sql=mysqli_query($conn,"select name,email from user");
	while($r=mysqli_fetch_array($sql))
	{
		echo "<option value='".$r['email']."'>".$r['name']."</option>";
	}
			?>
		</select>
		</div>
	</div>
<div class="row">
		<div class="col-sm-4">Select Staff</div>
		<div class="col-sm-5">
		<select name="user[]" multiple="multiple" class="form-control">
			<?php 
	$sql=mysqli_query($conn,"select name,email from faculty");
	while($r=mysqli_fetch_array($sql))
	{
		echo "<option value='".$r['email']."'>".$r['name']."</option>";
	}
			?>
		</select>
		</div>
	</div>
	
	<div class="row" style="margin-top:10px">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
	</div>	
		
		<div class="row" style="margin-top:10px">
		<div class="col-sm-2"></div>
		<div class="col-sm-4">
		<input type="submit" value="Add New Notice" name="add" class="btn btn-success"/>
		<input type="reset" class="btn btn-success"/>
		</div>
	</div>
</form>	